## 1.0.8 (2025-04-16)

## Bug Fixes

- fix doc errors

## 1.0.7 (2025-03-08)

## Bug Fixes

- fix doc errors

## 1.0.6 (2025-03-05)

## Bug Fixes

- fix doc errors

## 1.0.5 (2025-01-05)

## Bug Fixes

- fix getopt errors

## 1.0.4 (2024-12-21)

## Bug Fixes

- fix doc errors

## 1.0.3 (2024-08-15)

## Bug Fixes

- fix sample rate divider bugs

## 1.0.2 (2024-08-06)

## Bug Fixes

- fix doc errors

## 1.0.1 (2024-07-01)

## Bug Fixes

- fix some display errors

## 1.0.0 (2022-08-30)

## Features

- first upload
